USE [GRASP]
GO

/****** Object:  Table [dbo].[UserToResponseStatus]    Script Date: 11/07/2014 18:07:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserToResponseStatus](
	[UTRSID] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[ResponseStatusID] [int] NOT NULL,
 CONSTRAINT [PK_UserToResponseStatus] PRIMARY KEY CLUSTERED 
(
	[UTRSID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

